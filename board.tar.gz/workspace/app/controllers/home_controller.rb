 require 'mailgun' 
class HomeController < ApplicationController
  def index
  end
  
  def write
    @title = params[:title]
    @email = params[:email]
    @message = params[:message]
    
    new_post = Post.new
    new_post.email = @email
    new_post.title = @title
    new_post.message = @message
    new_post.save
    
    mg_client = Mailgun::Client.new("key-4f4d689f03bc79d5715ff75203f4a45d")

    message_params =  {
                   from: 'butterflier.v@gmail.com',
                   to:   @email,
                   subject: @title,
                   text:    @message
                  }

    result = mg_client.send_message('sandbox4c498ada3e0c4d6489a4da0f87a968a4.mailgun.org', message_params).to_h!

    message_id = result['id']
    message = result['message']
    redirect_to "/home/list"
  end
  def list
    @every_post = Post.all
  end
end